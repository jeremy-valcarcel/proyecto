package com.jeremy.practica_proyecto.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Service;

import com.jeremy.practica_proyecto.models.Project;
import com.jeremy.practica_proyecto.models.User;
import com.jeremy.practica_proyecto.repositories.ProjectRepo;

@Service
public class ProjectService {
	private final ProjectRepo projectRepo;
	
	public  ProjectService(ProjectRepo pR) {
		this.projectRepo = pR;
	}
	
	public Project crearUnProject(Project project) {
		return projectRepo.save(project);
	}
	
	public Project actualizarUnProject(Project project) {
		return projectRepo.save(project);
	}
	
	public void borrar(Long id) {
		projectRepo.deleteById(id);
	}
	
	public void unirseDejarProject(Project project, User usuario, boolean ayudante) {
		if(ayudante) {
			project.getAyudantes().add(usuario);			
		}else {
			project.getAyudantes().remove(usuario);	
		}
		projectRepo.save(project);
	}
	
	public Project unProject(Long id) {
		return projectRepo.findById(id).orElse(null);
	}
	
	public List<Project> projectoParticipando(User usuario) {
        // Obtener proyectos en los que el usuario es el encargado (creador)
        List<Project> proyectosEncargado = projectRepo.findByEncargado(usuario);

        // Obtener proyectos en los que el usuario es un ayudante (participante)
        List<Project> proyectosAyudante = projectRepo.findByAyudantesContaining(usuario);

        // Combinar las listas de proyectos del usuario (creador y participante)
        List<Project> proyectosParticipando = new ArrayList<>(proyectosEncargado);
        proyectosParticipando.addAll(proyectosAyudante);

        return proyectosParticipando;
	}
	
	public List<Project> projectoNotParticipando(User usuario) {
		return projectRepo.findByAyudantesNotContaining(usuario);
		
		
		
	}
	
}
